import pytest
import sys
import os
from unittest.mock import Mock, patch

# Add src to path for testing
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

import streamlit as st

class TestApp:
    
    @patch('app.AWSServices')
    def test_get_aws_services_cached(self, mock_aws_services):
        from app import get_aws_services
        
        # Clear any existing cache
        get_aws_services.clear()
        
        # First call
        result1 = get_aws_services()
        
        # Second call should return cached instance
        result2 = get_aws_services()
        
        assert result1 is result2
        mock_aws_services.assert_called_once()
    
    @patch.dict('os.environ', {'S3_BUCKET_NAME': '', 'S3_REGION': 'us-east-1'})
    @patch('streamlit.error')
    def test_main_missing_bucket_name(self, mock_error):
        from app import main
        
        with patch('streamlit.set_page_config'), \
             patch('streamlit.title'), \
             patch('streamlit.markdown'):
            main()
        
        mock_error.assert_called_once()