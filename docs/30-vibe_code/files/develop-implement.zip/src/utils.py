from PIL import Image
from io import BytesIO

def bytes_to_image(image_bytes):
    return Image.open(BytesIO(image_bytes))

def extract_filename_info(key):
    filename = key.split('/')[-1]
    # Remove .png extension
    if filename.endswith('.png'):
        filename = filename[:-4]
    
    parts = filename.split('_')
    if len(parts) >= 3:
        date_part = parts[0]
        time_part = parts[1]
        prompt_part = '_'.join(parts[2:])
        return f"{date_part} {time_part}", prompt_part.replace('_', ' ')
    return filename, ""