import boto3
import json
import base64
from datetime import datetime
from io import BytesIO
from PIL import Image
import os
from dotenv import load_dotenv

load_dotenv()

class AWSServices:
    def __init__(self):
        self.bedrock_client = boto3.client('bedrock-runtime', region_name='us-east-1')
        self.s3_client = boto3.client('s3', region_name=os.getenv('S3_REGION'))
        self.bucket_name = os.getenv('S3_BUCKET_NAME')
        
    def generate_image(self, prompt, style=None):
        text_params = {"text": prompt}
        if style:
            text_params["style"] = style
            
        payload = {
            "taskType": "TEXT_IMAGE",
            "textToImageParams": text_params,
            "imageGenerationConfig": {
                "width": 1024,
                "height": 1024,
                "quality": "standard",
                "numberOfImages": 1
            }
        }
        
        response = self.bedrock_client.invoke_model(
            modelId="amazon.nova-canvas-v1:0",
            body=json.dumps(payload)
        )
        
        response_body = json.loads(response['body'].read())
        image_data = response_body['images'][0]
        return base64.b64decode(image_data)
    
    def upload_to_s3(self, image_data, prompt):
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"generated_images/{timestamp}_{prompt[:30].replace(' ', '_')}.png"
        
        self.s3_client.put_object(
            Bucket=self.bucket_name,
            Key=filename,
            Body=image_data,
            ContentType='image/png'
        )
        return filename
    
    def list_images(self):
        response = self.s3_client.list_objects_v2(
            Bucket=self.bucket_name,
            Prefix='generated_images/'
        )
        
        images = []
        if 'Contents' in response:
            for obj in sorted(response['Contents'], key=lambda x: x['LastModified'], reverse=True):
                images.append(obj['Key'])
        return images
    
    def get_image_url(self, key):
        return self.s3_client.generate_presigned_url(
            'get_object',
            Params={'Bucket': self.bucket_name, 'Key': key},
            ExpiresIn=3600
        )