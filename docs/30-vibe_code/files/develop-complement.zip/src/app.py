import streamlit as st
from aws_services import AWSServices
from utils import bytes_to_image, extract_filename_info
import os

st.set_page_config(page_title="AWS AI Image Gallery", layout="wide")

@st.cache_resource
def get_aws_services():
    return AWSServices()

def main():
    st.title("🎨 AWS AI Image Gallery")
    st.markdown("Amazon Nova Canvas로 AI 이미지를 생성하고 갤러리에서 확인하세요!")
    
    # 환경변수 확인
    if not os.getenv('S3_BUCKET_NAME') or os.getenv('S3_BUCKET_NAME') == 'your-bucket-name':
        st.error("⚠️ .env 파일에서 S3_BUCKET_NAME을 설정해주세요.")
        return
    
    aws_services = get_aws_services()
    
    # 레이아웃 구성
    col1, col2 = st.columns([1, 2])
    
    with col1:
        st.header("🖼️ 이미지 생성")
        
        prompt = st.text_area(
            "텍스트 프롬프트를 입력하세요:",
            placeholder="예: A beautiful sunset over mountains",
            height=100
        )
        
        # 스타일 선택
        style_options = {
            "기본 (스타일 없음)": None,
            "포토리얼리즘": "PHOTOREALISM",
            "3D 애니메이션": "3D_ANIMATED_FAMILY_FILM",
            "디자인 스케치": "DESIGN_SKETCH",
            "플랫 벡터": "FLAT_VECTOR_ILLUSTRATION",
            "그래픽 노블": "GRAPHIC_NOVEL_ILLUSTRATION",
            "맥시멀리즘": "MAXIMALISM",
            "미드센추리 레트로": "MIDCENTURY_RETRO",
            "소프트 디지털 페인팅": "SOFT_DIGITAL_PAINTING"
        }
        
        selected_style = st.selectbox(
            "스타일 선택:",
            options=list(style_options.keys()),
            help="이미지 생성에 적용할 시각적 스타일을 선택하세요"
        )
        
        if st.button("이미지 생성", type="primary", use_container_width=True):
            if prompt.strip():
                with st.spinner("이미지 생성 중..."):
                    try:
                        # 이미지 생성
                        style_value = style_options[selected_style]
                        image_data = aws_services.generate_image(prompt, style_value)
                        
                        # S3에 업로드
                        filename = aws_services.upload_to_s3(image_data, prompt)
                        
                        # 생성된 이미지 표시
                        image = bytes_to_image(image_data)
                        st.image(image, caption=f"생성된 이미지: {prompt}", use_container_width=True)
                        st.success(f"✅ 이미지가 생성되어 S3에 저장되었습니다!")
                        
                        # 갤러리 새로고침을 위해 캐시 클리어
                        st.rerun()
                        
                    except Exception as e:
                        st.error(f"❌ 오류가 발생했습니다: {str(e)}")
            else:
                st.warning("프롬프트를 입력해주세요.")
    
    with col2:
        st.header("🖼️ 이미지 갤러리")
        
        try:
            images = aws_services.list_images()
            
            if images:
                # 갤러리 그리드 구성
                cols = st.columns(3)
                
                for idx, image_key in enumerate(images[:12]):  # 최대 12개 표시
                    col_idx = idx % 3
                    
                    with cols[col_idx]:
                        try:
                            image_url = aws_services.get_image_url(image_key)
                            timestamp, prompt_info = extract_filename_info(image_key)
                            
                            st.image(
                                image_url,
                                caption=f"{timestamp}\n{prompt_info[:50]}...",
                                use_container_width=True
                            )
                            
                        except Exception as e:
                            st.error(f"이미지 로드 실패: {str(e)}")
                
                if len(images) > 12:
                    st.info(f"총 {len(images)}개 이미지 중 최근 12개를 표시합니다.")
            else:
                st.info("아직 생성된 이미지가 없습니다. 왼쪽에서 이미지를 생성해보세요!")
                
        except Exception as e:
            st.error(f"갤러리 로드 중 오류: {str(e)}")

if __name__ == "__main__":
    main()