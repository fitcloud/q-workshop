import pytest
import json
import base64
import sys
import os
from unittest.mock import Mock, patch

# Add src to path for testing
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from aws_services import AWSServices

@pytest.fixture
def aws_services():
    with patch.dict('os.environ', {'S3_BUCKET_NAME': 'test-bucket', 'S3_REGION': 'us-east-1'}):
        with patch('boto3.client'):
            return AWSServices()

@pytest.fixture
def mock_image_data():
    return base64.b64encode(b'fake_image_data').decode()

class TestAWSServices:
    
    def test_generate_image_success(self, aws_services, mock_image_data):
        # Mock Bedrock response
        mock_response = {
            'body': Mock()
        }
        mock_response['body'].read.return_value = json.dumps({
            'images': [mock_image_data]
        }).encode()
        
        aws_services.bedrock_client.invoke_model.return_value = mock_response
        
        result = aws_services.generate_image("test prompt")
        
        assert result == b'fake_image_data'
        aws_services.bedrock_client.invoke_model.assert_called_once()
    
    def test_generate_image_with_style(self, aws_services, mock_image_data):
        # Mock Bedrock response
        mock_response = {
            'body': Mock()
        }
        mock_response['body'].read.return_value = json.dumps({
            'images': [mock_image_data]
        }).encode()
        
        aws_services.bedrock_client.invoke_model.return_value = mock_response
        
        result = aws_services.generate_image("test prompt", "PHOTOREALISM")
        
        assert result == b'fake_image_data'
        # Check that style was included in the payload
        call_args = aws_services.bedrock_client.invoke_model.call_args
        body = json.loads(call_args[1]['body'])
        assert body['textToImageParams']['style'] == 'PHOTOREALISM'
    
    def test_generate_image_failure(self, aws_services):
        aws_services.bedrock_client.invoke_model.side_effect = Exception("Bedrock error")
        
        with pytest.raises(Exception, match="Bedrock error"):
            aws_services.generate_image("test prompt")
    
    def test_upload_to_s3_success(self, aws_services):
        image_data = b'test_image_data'
        prompt = "test prompt"
        
        result = aws_services.upload_to_s3(image_data, prompt)
        
        assert result.startswith("generated_images/")
        assert "test_prompt" in result
        aws_services.s3_client.put_object.assert_called_once()
    
    def test_upload_to_s3_failure(self, aws_services):
        aws_services.s3_client.put_object.side_effect = Exception("S3 error")
        
        with pytest.raises(Exception, match="S3 error"):
            aws_services.upload_to_s3(b'data', "prompt")
    
    def test_list_images_success(self, aws_services):
        mock_response = {
            'Contents': [
                {'Key': 'generated_images/image1.png', 'LastModified': '2024-01-01'},
                {'Key': 'generated_images/image2.png', 'LastModified': '2024-01-02'}
            ]
        }
        aws_services.s3_client.list_objects_v2.return_value = mock_response
        
        result = aws_services.list_images()
        
        assert len(result) == 2
        assert 'generated_images/image2.png' == result[0]  # Most recent first
    
    def test_list_images_empty(self, aws_services):
        aws_services.s3_client.list_objects_v2.return_value = {}
        
        result = aws_services.list_images()
        
        assert result == []
    
    def test_get_image_url_success(self, aws_services):
        aws_services.s3_client.generate_presigned_url.return_value = "https://test-url.com"
        
        result = aws_services.get_image_url("test-key")
        
        assert result == "https://test-url.com"
        aws_services.s3_client.generate_presigned_url.assert_called_once_with(
            'get_object',
            Params={'Bucket': 'test-bucket', 'Key': 'test-key'},
            ExpiresIn=3600
        )