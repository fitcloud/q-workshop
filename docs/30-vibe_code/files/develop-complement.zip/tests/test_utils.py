import pytest
import sys
import os
from PIL import Image
from io import BytesIO

# Add src to path for testing
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from utils import bytes_to_image, extract_filename_info

class TestUtils:
    
    def test_bytes_to_image_success(self):
        # Create a simple test image
        img = Image.new('RGB', (100, 100), color='red')
        img_bytes = BytesIO()
        img.save(img_bytes, format='PNG')
        img_bytes = img_bytes.getvalue()
        
        result = bytes_to_image(img_bytes)
        
        assert isinstance(result, Image.Image)
        assert result.size == (100, 100)
    
    def test_bytes_to_image_invalid_data(self):
        with pytest.raises(Exception):
            bytes_to_image(b'invalid_image_data')
    
    def test_extract_filename_info_valid_format(self):
        key = "generated_images/20240101_123456_beautiful_sunset.png"
        
        timestamp, prompt = extract_filename_info(key)
        
        assert timestamp == "20240101 123456"
        assert prompt == "beautiful sunset"
    
    def test_extract_filename_info_simple_format(self):
        key = "generated_images/simple_file.png"
        
        timestamp, prompt = extract_filename_info(key)
        
        assert timestamp == "simple_file"
        assert prompt == ""
    
    def test_extract_filename_info_complex_prompt(self):
        key = "generated_images/20240101_123456_a_beautiful_mountain_landscape.png"
        
        timestamp, prompt = extract_filename_info(key)
        
        assert timestamp == "20240101 123456"
        assert prompt == "a beautiful mountain landscape"