# Changelog

## [1.1.0] - 2024-12-19

### Added
- **스타일 선택 기능**: Amazon Nova Canvas의 사전 정의된 8가지 시각적 스타일 지원
  - 포토리얼리즘 (PHOTOREALISM)
  - 3D 애니메이션 (3D_ANIMATED_FAMILY_FILM)
  - 디자인 스케치 (DESIGN_SKETCH)
  - 플랫 벡터 (FLAT_VECTOR_ILLUSTRATION)
  - 그래픽 노블 (GRAPHIC_NOVEL_ILLUSTRATION)
  - 맥시멀리즘 (MAXIMALISM)
  - 미드센추리 레트로 (MIDCENTURY_RETRO)
  - 소프트 디지털 페인팅 (SOFT_DIGITAL_PAINTING)

### Changed
- `AWSServices.generate_image()` 메서드에 선택적 `style` 파라미터 추가
- Streamlit UI에 스타일 선택 드롭다운 추가
- 테스트 케이스에 스타일 파라미터 검증 로직 추가

### Technical Details
- Nova Canvas API의 `textToImageParams`에 `style` 필드 조건부 추가
- 사용자 친화적인 한국어 스타일 이름과 API 값 매핑
- 기본값은 스타일 없음으로 설정하여 기존 동작 유지

## [1.0.0] - 2024-12-19

### Initial Release
- Amazon Nova Canvas를 이용한 텍스트-이미지 생성 기능
- S3 자동 업로드 및 저장
- Streamlit 기반 웹 인터페이스
- 기본 이미지 갤러리 기능