# 리소스 정리

---

!!! info
    워크숍 스튜디오를 사용하는 AWS 가이드 이벤트에서는 이벤트에 사용된 리소스가 자동으로 제거되므로 아래의 정리 과정을 실행할 필요가 없습니다.

생성한 Cloudformation 스택을 삭제합니다.
![delete](./images/delete.png)